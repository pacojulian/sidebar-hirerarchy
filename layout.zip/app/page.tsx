export default function Page() {
  return <div>{/* You can add any content here, or leave it empty */}</div>
}

